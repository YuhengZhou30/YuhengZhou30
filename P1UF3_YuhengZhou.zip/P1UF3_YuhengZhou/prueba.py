'''#conversion datos file to lista de lista
f=open('file.txt')
f=f.readlines()
l=[]
for i in f:
    print(i)
    i=i.split('#')
    l.append(i)
#conversion datos file to lista de lista '''
#
'''f=open('file.txt','a+')
f.write('\nwdwwd')
f.close()'''

f=('regergegg')
f=str(f)
print(f)