import random
#conversion datos file to lista de lista
f=open('file.txt')
f=f.readlines()
l=[]
for i in f:
    i=i.split('#')
    l.append(i)
#conversion datos file to lista de lista
def A(opc):
    # <int>#<NumCli>#<str># <nom> #<str># <AP1> #<str># <ap2> #<str># <dir> #<str># <cp>#<str> <pob>#<str> # <pro> <ENTER>
    while True:
        try:
            #generar ID y buscar si exite
            while True:
                NumCli=random.randint(1,999)
                for i in range(len(l)-1):
                    if NumCli==l[int(i)][1]:
                        break
                    elif NumCli!=l[i][1]:
                        valid=True
                        break
                if valid==True:
                    break
            print('The client ID will be',NumCli)
            # generar ID y buscar si exite
            #Demana el nom del client
            nom=input('Write the name for the client')
            # Demana el nom del client
            #demana apellido 1
            AP1=input('Write the first surname')
            #demana apellido 1
            #demana apellido 2
            AP2=input('Write the second surname')
            # demana apellido 2
            # demana direccio
            dir=input('Write the direction')
            #demana direccio
            #demana codi postal
            CP=int(input('Write the Postal code'))
            #demana codi postal
            #demana poblacio
            pob=input('Write the poblation')
            # demana poblacio
            # demana provincia
            pro=input('Write the province')
            # demana provincia
            f = open('file.txt', 'a+')
            # <int>#<NumCli>#<str># <nom> #<str># <AP1> #<str># <ap2> #<str># <dir> #<str># <cp>#<str> <pob>#<str> # <pro> <ENTER>
            writefinal='\nint#'+str(NumCli)+'#str#'+nom+'#str#'+str(AP1)+'#str#'+str(AP2)+'#str#'+str(dir)+'#str#'+str(CP)+'#str#'+pob+'#str#'+pro
            writefinal=str(writefinal)
            f.write(writefinal)
            f.close()
            print('Data safed')
            return ''

        except ValueError or TypeError:
            print('Error code 0x2332(you tried to input a some extrange things')
            input('Enter to try again')

def menu():
    error = True
    while error == True:
        menu = "A. Introduir un client nou des del teclat\nB. Mostrar clients ordenats per número de client\nC. Carregar dades des d'un arxiu de text\nD. Desar les dades en un arxiu de text\nE. Eliminar un client\nF. Mostrar client buscant-lo pel nom i cognoms\nF. Mostrar client buscant-lo pel nom i cognoms\nX. Sortir del programa".split('\n')
        print(' '*10,'M E N U    P R I N C I P A L')
        print('='*50)
        for i in menu:
            print(i)
        opc = input('-->Option:')
        if opc.isalpha()==True:
            opc=opc.upper()
        if opc == 'A' or opc == 'B' or opc == 'C' or opc == 'D' or opc == 'E'or opc == 'F'or opc == 'X':
            return opc
        else:
            input('**********Invalid option**********\n\n Press enter to continue')

            error = True

#<int>#<NumCli>#<str># <nom> #<str># <AP1> #<str># <ap2> #<str># <dir> #<str># <cp>#<str> <pob>#<str> # <pro> <ENTER>
opc=menu()
print(A(opc))